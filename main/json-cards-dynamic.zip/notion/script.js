/* const notionDocId = "0cb628857f3c4c77bf7f9a879a6ec21d"

 fetch("https://potion-api.now.sh/html?id=" + notionDocId)
  .then(res => res.text())
  .then(text => {
    document.querySelector("main").innerHTML = text
  })  
  
  
  
  
  fetch("https://potion-api.now.sh/table?id=2364751436224832ba85e279417ea798")
      .then(res => res.text())
      .then(text => {
            document.querySelector("main").innerHTML = text
      })
      
  */


 let theFields= [];

fetch("https://potion-api.now.sh/table?id=2364751436224832ba85e279417ea798")
      .then(res => res.json())
      .then(data => {
        console.log(data);
        console.log(data[0]);
        
        for (var i = 0; i < data.length; i++) {
        
        theFields = data[i].emoji;
        
            
          
        
        console.log('theFields: ' + theFields)    ;
        
        //** console.log('theFieldsArray?: ' + theFieldsArray)    ;
        
        
        document.querySelector("main").innerHTML = theFields;
        console.log('theFieldsArray?inside: ' + theFields)    ;
        };

document.querySelector("test").innerHTML = `<p> ${theFields} </p> <br />`;

        console.log('theFieldsArray?after: ' + theFields)    ;
      })
      
      
    